var app = angular.module("myApp");

app.controller('frontpageController',function($scope){

});
